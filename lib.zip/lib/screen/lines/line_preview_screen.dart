import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:go_router/go_router.dart';

import 'package:quevebus/core/routing/models.dart'; // BusLine

class LinePreviewScreen extends StatefulWidget {
  final BusLine line;
  const LinePreviewScreen({super.key, required this.line});

  @override
  State<LinePreviewScreen> createState() => _LinePreviewScreenState();
}

class _LinePreviewScreenState extends State<LinePreviewScreen> {
  final MapController _mapCtrl = MapController();
  bool _mapReady = false;

  List<LatLng> _allPoints = const [];
  List<LatLng> _stops = const [];

  @override
  void initState() {
    super.initState();
    _prepareData();
  }

  void _prepareData() {
    final line = widget.line;

    // Unir todos los puntos de todos los segmentos para ajustar cámara
    final pts = <LatLng>[];
    for (final seg in line.segments) {
      pts.addAll(seg);
    }
    _allPoints = pts;

    // Paradas:
    // 1) Usa line.stops si existe (preferido)
    // 2) Fallback: marca el primer y último punto de cada segmento
    final stops = <LatLng>[];
    try {
      final s = (line.stops ?? <LatLng>[]);
      if (s.isNotEmpty) {
        stops.addAll(s);
      } else {
        for (final seg in line.segments) {
          if (seg.isNotEmpty) {
            stops.add(seg.first);
            stops.add(seg.last);
          }
        }
      }
    } catch (_) {
      // si el modelo aún no tiene stops
      for (final seg in line.segments) {
        if (seg.isNotEmpty) {
          stops.add(seg.first);
          stops.add(seg.last);
        }
      }
    }
    _stops = stops;
  }

  void _onMapReady() {
    _mapReady = true;
    _fitBounds();
  }

  void _fitBounds() {
    if (!_mapReady || _allPoints.isEmpty) return;
    final bounds = LatLngBounds.fromPoints(_allPoints);
    _mapCtrl.fitCamera(
      CameraFit.bounds(
        bounds: bounds,
        padding: const EdgeInsets.fromLTRB(28, 140, 28, 60),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final line = widget.line;
    final title = (line.name?.isNotEmpty == true) ? line.name! : 'Línea ${line.id}';

    return Scaffold(
      appBar: AppBar(
        title: Text('Vista de $title'),
        actions: [
          IconButton(
            tooltip: 'Reencuadrar',
            onPressed: _fitBounds,
            icon: const Icon(Icons.center_focus_strong),
          ),
        ],
      ),
      body: FlutterMap(
        mapController: _mapCtrl,
        options: MapOptions(
          initialCenter: _allPoints.isNotEmpty ? _allPoints.first : const LatLng(-1.0286, -79.4594),
          initialZoom: 14.0,
          onMapReady: _onMapReady,
          interactionOptions: const InteractionOptions(
            flags: InteractiveFlag.drag | InteractiveFlag.pinchZoom | InteractiveFlag.doubleTapZoom,
          ),
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.example.quevebus',
            retinaMode: true,
          ),

          // Trazado completo (puede venir en varios segmentos)
          PolylineLayer(
            polylines: [
              for (final seg in line.segments)
                Polyline(
                  points: seg,
                  strokeWidth: 6,
                  color: const Color(0xFF1565C0), // azul estilo Google
                ),
            ],
          ),

          // Paradas (rojo)
          MarkerLayer(
            markers: [
              for (final p in _stops)
                Marker(
                  point: p,
                  width: 12,
                  height: 12,
                  alignment: Alignment.center,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.red.shade600,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 1.5),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: _infoBar(line),
    );
  }

  Widget _infoBar(BusLine line) {
    final totalPts = _allPoints.length;
    final nStops = _stops.length;
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)],
      ),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
      child: Row(
        children: [
          const Icon(Icons.directions_bus_filled, color: Colors.black87),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Segmentos: ${line.segments.length}  •  Puntos: $totalPts  •  Paradas: $nStops',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          TextButton(
            onPressed: () => context.pop(),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }
}
