// lib/screen/results/routes_result_screen.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:go_router/go_router.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import 'package:quevebus/core/services/lines_repository.dart';
import 'package:quevebus/core/routing/models.dart';
import 'package:quevebus/core/routing/router.dart';

/// ---------- Resultado para la ruta global (OSRM) ----------
class GlobalRouteResult {
  final List<LatLng> points;
  final double distanceMeters;
  final double durationSeconds;
  GlobalRouteResult({
    required this.points,
    required this.distanceMeters,
    required this.durationSeconds,
  });
}

/// Servicio OSRM para ruteo “tipo Google Maps”
class GlobalRouteService {
  static const _baseUrl = 'https://router.project-osrm.org';

  static Future<GlobalRouteResult?> fetchRoute({
    required LatLng origin,
    required LatLng destination,
    Duration timeout = const Duration(seconds: 8),
  }) async {
    try {
      final url =
          '$_baseUrl/route/v1/driving/${origin.longitude},${origin.latitude};${destination.longitude},${destination.latitude}?overview=full&geometries=geojson&steps=false';
      final resp = await http
          .get(Uri.parse(url), headers: {'User-Agent': 'QueveBus/1.0'})
          .timeout(timeout);

      if (resp.statusCode != 200) return null;

      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final routes = (data['routes'] as List?) ?? const [];
      if (routes.isEmpty) return null;

      final r = routes.first as Map<String, dynamic>;
      final geom = (r['geometry'] as Map)['coordinates'] as List;
      final dist = (r['distance'] as num).toDouble();
      final dur = (r['duration'] as num).toDouble();

      final pts = <LatLng>[
        for (final c in geom) LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble())
      ];

      return GlobalRouteResult(points: pts, distanceMeters: dist, durationSeconds: dur);
    } catch (_) {
      return null;
    }
  }
}

/// -------------------- Pantalla --------------------
enum RouteViewMode { global, bus }

class RoutesResultScreen extends StatefulWidget {
  final double? destLat;
  final double? destLon;

  const RoutesResultScreen({super.key, this.destLat, this.destLon});

  @override
  State<RoutesResultScreen> createState() => _RoutesResultScreenState();
}

class _RoutesResultScreenState extends State<RoutesResultScreen> {
  final MapController _mapCtrl = MapController();

  LatLng? _origin;
  LatLng? _destination;

  bool _loading = true;
  String? _error;

  // Ruta global (azul)
  GlobalRouteResult? _global;

  // Ruta con buses (legs)
  Itinerary? _itinerary;

  // UI
  RouteViewMode _mode = RouteViewMode.global;
  bool _mapReady = false;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    // 1) Validar destino
    if (widget.destLat == null || widget.destLon == null) {
      setState(() {
        _loading = false;
        _error = 'No se recibió un destino válido.';
      });
      return;
    }
    _destination = LatLng(widget.destLat!, widget.destLon!);

    // 2) Origen (ubicación del dispositivo o fallback)
    LatLng? pos;
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if ((perm == LocationPermission.always ||
              perm == LocationPermission.whileInUse) &&
          await Geolocator.isLocationServiceEnabled()) {
        final p = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
        );
        pos = LatLng(p.latitude, p.longitude);
      }
    } catch (_) {}
    pos ??= const LatLng(-1.0286, -79.4594);
    _origin = pos;

    // 3) Ejecutar en paralelo: global (OSRM) + bus (tu router)
    try {
      final globalF = GlobalRouteService.fetchRoute(
        origin: _origin!,
        destination: _destination!,
      );

      final busF = _buildBusItinerary(_origin!, _destination!);

      final results = await Future.wait([globalF, busF]);

      _global = results[0] as GlobalRouteResult?;
      _itinerary = results[1] as Itinerary?;

      setState(() {
        _loading = false;
        // si no hay global pero sí bus, arrancamos en bus
        if (_global == null && _itinerary != null) {
          _mode = RouteViewMode.bus;
        }
        // si no hay ninguno, mostrar error
        if (_global == null && _itinerary == null) {
          _error =
              'No se pudo trazar la ruta. Verifica tu conexión y que existan líneas cercanas.';
        }
      });

      if (_mapReady) _fitBounds();
    } catch (e) {
      setState(() {
        _loading = false;
        _error = 'Error al calcular rutas: $e';
      });
    }
  }

  Future<Itinerary?> _buildBusItinerary(LatLng origin, LatLng dest) async {
    try {
      final repo = LinesRepository();
      final lines = await repo.loadFromAssets(); // assets/bus/lines.geojson

      final router = BusRouter(
        lines: lines,
        opts: const RouterOptions(
          nodeStepMeters: 300.0,
          walkRadiusStartEnd: 300.0,
          walkRadiusTransfer: 150.0,
          transferPenaltyMin: 3.0,
        ),
      );

      return router.route(origin, dest);
    } catch (_) {
      return null;
    }
  }

  void _onMapReady() {
    _mapReady = true;
    _fitBounds();
  }

  void _fitBounds() {
    if (!_mapReady) return;
    final pts = <LatLng>[];

    if (_mode == RouteViewMode.global && _global != null) {
      pts.addAll(_global!.points);
    } else if (_mode == RouteViewMode.bus && _itinerary != null) {
      for (final leg in _itinerary!.legs) {
        pts.addAll(leg.shape);
      }
    }
    if (pts.isEmpty) return;

    final bounds = LatLngBounds.fromPoints(pts);
    _mapCtrl.fitCamera(
      CameraFit.bounds(
        bounds: bounds,
        padding: const EdgeInsets.fromLTRB(28, 140, 28, 260),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    if (_loading) {
      return const Scaffold(
        body: SafeArea(child: Center(child: CircularProgressIndicator())),
      );
    }
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Resultados')),
        body: Center(child: Text(_error!)),
      );
    }

    // info inferior
    final busLines = _itinerary?.legs
            .where((l) => l.mode == LegMode.bus)
            .map((l) => l.lineId ?? 'L?')
            .toList() ??
        const <String>[];
    final busTotal = _itinerary?.totalMinutes ?? 0.0;
    final globalMin = _global != null ? (_global!.durationSeconds / 60.0) : null;
    final globalKm = _global != null ? (_global!.distanceMeters / 1000.0) : null;

    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            // ================= MAPA =================
            Positioned.fill(
              child: FlutterMap(
                mapController: _mapCtrl,
                options: MapOptions(
                  initialCenter:
                      _destination ?? _origin ?? const LatLng(-1.0286, -79.4594),
                  initialZoom: 14.5,
                  onMapReady: _onMapReady,
                  interactionOptions: const InteractionOptions(
                    flags: InteractiveFlag.drag |
                        InteractiveFlag.pinchZoom |
                        InteractiveFlag.doubleTapZoom,
                  ),
                ),
                children: [
                  TileLayer(
                    urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.example.quevebus',
                    retinaMode: true,
                  ),

                  // --- Ruta GLOBAL (azul, como Google Maps) ---
                  if (_mode == RouteViewMode.global && _global != null)
                    PolylineLayer(
                      polylines: [
                        Polyline(
                          points: _global!.points,
                          strokeWidth: 7,
                          color: const Color(0xFF1565C0),
                        ),
                      ],
                    ),

                  // --- Ruta BUS (tramos; bus en primario, walk punteado) ---
                  if (_mode == RouteViewMode.bus && _itinerary != null)
                    PolylineLayer(
                      polylines: [
                        for (final leg in _itinerary!.legs)
                          Polyline(
                            points: leg.shape,
                            strokeWidth: leg.mode == LegMode.bus ? 6 : 4,
                            color: leg.mode == LegMode.bus
                                ? cs.primary
                                : Colors.black45,
                            isDotted: leg.mode == LegMode.walk,
                          ),
                      ],
                    ),

                  // Marcadores de Origen/Destino
                  MarkerLayer(
                    markers: [
                      if (_origin != null)
                        Marker(
                          point: _origin!,
                          width: 40,
                          height: 40,
                          alignment: Alignment.topCenter,
                          child: const Icon(
                            Icons.my_location,
                            color: Colors.blue,
                            size: 28,
                          ),
                        ),
                      if (_destination != null)
                        Marker(
                          point: _destination!,
                          width: 42,
                          height: 42,
                          alignment: Alignment.topCenter,
                          child: const Icon(
                            Icons.location_on_rounded,
                            color: Colors.green,
                            size: 34,
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),

            // ===== BOTÓN BACK
            Positioned(
              top: 12,
              left: 12,
              child: Material(
                color: Colors.white,
                shape: const CircleBorder(),
                elevation: 1,
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () => context.pop(),
                  child: const Padding(
                    padding: EdgeInsets.all(10),
                    child: Icon(Icons.arrow_back_rounded, size: 22),
                  ),
                ),
              ),
            ),

            // ===== SEGMENTED (conmutador) =====
            Positioned(
              top: 12,
              left: 62,
              right: 12,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 6)],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('Ruta global'),
                        selected: _mode == RouteViewMode.global,
                        onSelected: (_global != null)
                            ? (v) {
                                if (v) {
                                  setState(() => _mode = RouteViewMode.global);
                                  _fitBounds();
                                }
                              }
                            : null,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('Rutas bus'),
                        selected: _mode == RouteViewMode.bus,
                        onSelected: (_itinerary != null)
                            ? (v) {
                                if (v) {
                                  setState(() => _mode = RouteViewMode.bus);
                                  _fitBounds();
                                }
                              }
                            : null,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // ===== PANEL INFERIOR =====
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
                  boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)],
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (_mode == RouteViewMode.global && _global != null) ...[
                        Row(
                          children: [
                            const Icon(Icons.navigation_rounded),
                            const SizedBox(width: 8),
                            const Expanded(
                              child: Text(
                                'Ruta global (tipo Google Maps)',
                                style: TextStyle(fontWeight: FontWeight.w800),
                              ),
                            ),
                            Text(
                              '${(globalMin!).toStringAsFixed(0)} min',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            '${globalKm!.toStringAsFixed(1)} km por calles y avenidas',
                            style: const TextStyle(color: Colors.black54),
                          ),
                        ),
                      ] else if (_mode == RouteViewMode.bus && _itinerary != null) ...[
                        Row(
                          children: [
                            const Icon(Icons.directions_transit_filled),
                            const SizedBox(width: 8),
                            const Expanded(
                              child: Text(
                                'Itinerario con buses',
                                style: TextStyle(fontWeight: FontWeight.w800),
                              ),
                            ),
                            Text(
                              '${busTotal.toStringAsFixed(0)} min',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Wrap(
                            spacing: 6,
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              const Icon(Icons.directions_walk, size: 16),
                              const Text('›'),
                              const Icon(Icons.directions_bus, size: 16),
                              const Text('›'),
                              const Icon(Icons.directions_walk, size: 16),
                              const SizedBox(width: 8),
                              for (final l in busLines)
                                _LinePill(text: l, color: cs.primary),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: TextButton(
                            onPressed: () =>
                                context.push('/itinerary', extra: _itinerary),
                            child: const Text('Ver detalles'),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LinePill extends StatelessWidget {
  final String text;
  final Color color;
  const _LinePill({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}
