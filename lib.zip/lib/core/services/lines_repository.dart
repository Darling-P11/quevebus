// lib/core/services/lines_repository.dart
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:latlong2/latlong.dart';

class BusLine {
  final String id;
  final List<List<LatLng>>
  segments; // una línea puede venir en varios segmentos
  BusLine({required this.id, required this.segments});
}

class LinesRepository {
  Future<List<BusLine>> loadFromAssets({
    String assetPath = 'assets/bus/lines.geojson',
  }) async {
    final raw = await rootBundle.loadString(assetPath);
    final data = jsonDecode(raw) as Map<String, dynamic>;
    final features = (data['features'] as List).cast<Map<String, dynamic>>();

    final Map<String, List<List<LatLng>>> grouped = {};
    for (final f in features) {
      final props = (f['properties'] ?? {}) as Map<String, dynamic>;
      final id = (props['id'] ?? 'line') as String;
      final coords = (f['geometry']['coordinates'] as List)
          .map(
            (c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()),
          )
          .toList();
      if (coords.length < 2) continue;
      grouped.putIfAbsent(id, () => []).add(coords);
    }

    return grouped.entries
        .map((e) => BusLine(id: e.key, segments: e.value))
        .toList();
  }
}
